"""Menu interaktif Tugas Pertemuan 8 (pakai class dari tugas_pertemuan_8.py)"""
from array import array
from tugas_pertemuan_8 import LinkedList, demo_array, demo_linked_list, demo_tuple


def menu_array():
    data = array('i', [85, 70, 90])
    while True:
        print("\n--- MENU ARRAY ---", list(data))
        print("1. Tambah  2. Hapus  3. Statistik  0. Kembali")
        p = input("Pilih: ").strip()
        if p == "1":
            try:
                data.append(int(input("Nilai: ")))
            except ValueError:
                print("Input harus angka!")
        elif p == "2":
            try:
                data.remove(int(input("Nilai yang dihapus: ")))
            except ValueError:
                print("Nilai tidak ditemukan / bukan angka!")
        elif p == "3":
            if data:
                print(f"Max={max(data)} Min={min(data)} Rata-rata={sum(data)/len(data):.2f}")
            else:
                print("Array kosong.")
        elif p == "0":
            return


def menu_linked_list():
    ll = LinkedList()
    while True:
        print("\n--- MENU LINKED LIST ---")
        ll.tampilkan()
        print("1. Tambah awal  2. Tambah akhir  3. Hapus  4. Cari  0. Kembali")
        p = input("Pilih: ").strip()
        if p == "1":
            ll.tambah_awal(input("Data: "))
        elif p == "2":
            ll.tambah_akhir(input("Data: "))
        elif p == "3":
            print("Dihapus" if ll.hapus(input("Data: ")) else "Tidak ditemukan")
        elif p == "4":
            pos = ll.cari(input("Data: "))
            print(f"Ada di posisi {pos}" if pos >= 0 else "Tidak ditemukan")
        elif p == "0":
            return


def main():
    while True:
        print("\n===== TUGAS PERTEMUAN 8 =====")
        print("1. Array  2. Linked List  3. Tuple (demo)  4. Demo semua  0. Keluar")
        p = input("Pilih: ").strip()
        if p == "1":
            menu_array()
        elif p == "2":
            menu_linked_list()
        elif p == "3":
            demo_tuple()
        elif p == "4":
            demo_array(); demo_linked_list(); demo_tuple()
        elif p == "0":
            print("Selesai.")
            break


if __name__ == "__main__":
    main()
