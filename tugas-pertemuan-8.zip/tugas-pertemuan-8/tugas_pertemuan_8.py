"""
Tugas Pertemuan 8 - Struktur Data
Implementasi Array, Linked List, dan Tuple di Python
Studi kasus: pengelolaan data nilai mahasiswa
"""
from array import array


# =====================================================
# 1. ARRAY - menyimpan & mengelola sekumpulan data
# =====================================================
def demo_array():
    print("=" * 50)
    print("1. ARRAY - Nilai Ujian Mahasiswa")
    print("=" * 50)

    # 'i' = tipe data integer (semua elemen harus bertipe sama)
    nilai = array('i', [85, 70, 90, 65, 78])
    print("Data awal           :", list(nilai))

    nilai.append(95)                      # tambah di akhir
    print("Setelah append(95)  :", list(nilai))

    nilai.insert(2, 88)                   # sisip di indeks 2
    print("Setelah insert(2,88):", list(nilai))

    nilai[0] = 100                        # ubah elemen
    print("Ubah indeks 0 -> 100:", list(nilai))

    nilai.remove(65)                      # hapus berdasarkan nilai
    print("Setelah remove(65)  :", list(nilai))

    print("Elemen indeks ke-3  :", nilai[3])
    print("Jumlah data         :", len(nilai))
    print("Nilai tertinggi     :", max(nilai))
    print("Nilai terendah      :", min(nilai))
    print("Rata-rata           : %.2f" % (sum(nilai) / len(nilai)))

    print("Traversal:")
    for i, n in enumerate(nilai):
        print(f"  nilai[{i}] = {n}")
    print()


# =====================================================
# 2. LINKED LIST - node dan pointer
# =====================================================
class Node:
    def __init__(self, data):
        self.data = data      # isi node
        self.next = None      # pointer ke node berikutnya


class LinkedList:
    def __init__(self):
        self.head = None

    def tambah_awal(self, data):
        baru = Node(data)
        baru.next = self.head
        self.head = baru

    def tambah_akhir(self, data):
        baru = Node(data)
        if self.head is None:
            self.head = baru
            return
        cur = self.head
        while cur.next:
            cur = cur.next
        cur.next = baru

    def hapus(self, data):
        cur = self.head
        prev = None
        while cur:
            if cur.data == data:
                if prev:
                    prev.next = cur.next
                else:
                    self.head = cur.next
                return True
            prev = cur
            cur = cur.next
        return False

    def cari(self, data):
        cur = self.head
        posisi = 0
        while cur:
            if cur.data == data:
                return posisi
            cur = cur.next
            posisi += 1
        return -1

    def panjang(self):
        cur, n = self.head, 0
        while cur:
            n += 1
            cur = cur.next
        return n

    def tampilkan(self):
        if self.head is None:
            print("(kosong)")
            return
        cur = self.head
        hasil = []
        while cur:
            hasil.append(str(cur.data))
            cur = cur.next
        print(" -> ".join(hasil) + " -> None")


def demo_linked_list():
    print("=" * 50)
    print("2. LINKED LIST - Antrian Mahasiswa Bimbingan")
    print("=" * 50)

    ll = LinkedList()
    ll.tambah_akhir("Budi")
    ll.tambah_akhir("Siti")
    ll.tambah_akhir("Andi")
    print("Setelah tambah akhir (Budi, Siti, Andi):")
    ll.tampilkan()

    ll.tambah_awal("Rina")
    print("Setelah tambah awal (Rina):")
    ll.tampilkan()

    print("Cari 'Siti'  -> posisi:", ll.cari("Siti"))
    print("Cari 'Joko'  -> posisi:", ll.cari("Joko"), "(tidak ditemukan)")

    ll.hapus("Budi")
    print("Setelah hapus 'Budi':")
    ll.tampilkan()
    print("Panjang linked list:", ll.panjang())
    print()


# =====================================================
# 3. TUPLE - data tetap (immutable)
# =====================================================
def demo_tuple():
    print("=" * 50)
    print("3. TUPLE - Data Identitas Kampus (Immutable)")
    print("=" * 50)

    kampus = ("STT Cipasung", "Informatika", 2026)
    print("Tuple kampus     :", kampus)
    print("Elemen indeks 0  :", kampus[0])
    print("Slicing [0:2]    :", kampus[0:2])

    # unpacking
    nama, prodi, tahun = kampus
    print(f"Unpacking        : nama={nama}, prodi={prodi}, tahun={tahun}")

    # tuple berisi tuple (data mahasiswa)
    mahasiswa = (("Budi", 85), ("Siti", 90), ("Andi", 78))
    print("Daftar mahasiswa :")
    for nm, nl in mahasiswa:
        print(f"  {nm:<6} : {nl}")

    # tuple tidak bisa diubah
    try:
        kampus[0] = "Kampus Lain"
    except TypeError as e:
        print("Coba ubah tuple  -> TypeError:", e)

    # cara "mengubah": buat tuple baru
    kampus_baru = kampus + ("Aktif",)
    print("Tuple baru       :", kampus_baru)
    print("count(2026)      :", kampus.count(2026))
    print("index('Informatika'):", kampus.index("Informatika"))
    print()


# =====================================================
# PROGRAM UTAMA
# =====================================================
if __name__ == "__main__":
    demo_array()
    demo_linked_list()
    demo_tuple()
    print("Program selesai.")
