# Tugas Pertemuan 8 - Struktur Data (Python)

Implementasi tiga struktur data dasar di Python:

| Struktur | Implementasi |
|----------|--------------|
| Array | modul `array` (nilai ujian mahasiswa) |
| Linked List | class `Node` dan `LinkedList` (antrian bimbingan) |
| Tuple | data identitas kampus (immutable) |

## File
- `tugas_pertemuan_8.py` : program utama (demo ketiga struktur data)
- `menu_interaktif.py` : versi menu interaktif

## Cara menjalankan
```
python tugas_pertemuan_8.py
python menu_interaktif.py
```
